#!/usr/bin/env bash
# ============================================================
# lib/backup.sh — backup engine (site & bench level)
#
# Env contract:
#   PROJECT_BASE_DIR        bench root
#   PROJECT_BACKUP_DIR      backup destination (default:
#                           $PROJECT_BASE_DIR/backups)
#
# Bench-native backups (db dump + files) are produced with the
# bench `backup` command as the frappe user, then copied into a
# stamped directory under PROJECT_BACKUP_DIR.
#
#   backup::resolve_dir     — prints the configured backup dir
#   backup::stamp           — timestamp string
#   backup::site SITE       — single site backup → returns path
#   backup::all_sites       — every site, skips sites lacking apps
#   backup::prune SITE N    — keep the newest N backups of a site
# ============================================================

backup::resolve_dir() {
    echo "${PROJECT_BACKUP_DIR:-"${PROJECT_BASE_DIR}/backups"}"
}

backup::stamp() {
    date +%Y%m%d%H%M%S
}

# ------------------------------------------------------------
# Produce a bench-native backup for one site and relocate it.
# Prints the backup destination dir on success.
# ------------------------------------------------------------
backup::site() {
    local site="${1:-${SITE_NAME:-}}"

    [ -n "$site" ] || die "backup::site requires a site name"
    : "${PROJECT_BASE_DIR:?}"
    require_venv

    local bench_dir="${PROJECT_BASE_DIR}/bench"
    local backups_root
    backups_root="$(backup::resolve_dir)"
    local stamp_dir="${backups_root}/$(backup::stamp)"

    log "Backing up site: $site"

    mkdir -p "$stamp_dir"

    # ------------------------------------------------------------
    # bench-native backup (sql.gz + site files tar) as frappe
    # ------------------------------------------------------------
    run_in_venv bench --site "$site" backup --with-files

    # ------------------------------------------------------------
    # Move the freshly produced artifacts into the stamp dir
    # ------------------------------------------------------------
    local src_dir="$bench_dir/sites/$site/private/backups"

    if [ ! -d "$src_dir" ]; then
        die "bench did not create backup dir: $src_dir"
    fi

    local found=0
    local f
    for f in "$src_dir"/*.sql.gz "$src_dir"/*-database.sql.gz \
             "$src_dir"/*.tar "$src_dir"/*-private-files.tar; do
        [ -f "$f" ] || continue
        mv "$f" "$stamp_dir/"
        found=1
    done

    if [ "$found" -ne 1 ] && [ -z "$(ls -A "$src_dir" 2>/dev/null)" ]; then
        die "no backup artifacts produced for site $site"
    fi

    # Any remaining artifacts (e.g. public files tar) we still move
    [ -z "$(ls -A "$src_dir" 2>/dev/null)" ] || mv "$src_dir"/* "$stamp_dir/" || true

    log "Backup stored: $stamp_dir (site: $site)"
    echo "$stamp_dir"
}

# ------------------------------------------------------------
# Backup every site in the bench.
# Prints number of backed-up sites.
# ------------------------------------------------------------
backup::all_sites() {
    : "${PROJECT_BASE_DIR:?}"

    local stamp
    stamp="$(backup::stamp)"

    local count=0 site
    while read -r site; do
        [ -z "$site" ] && continue

        # Skip sites without any installed apps (memory-only sites)
        if ! grep -q . "$PROJECT_BASE_DIR/bench/sites/$site/apps.txt" 2>/dev/null; then
            log "Skipping site $site (no apps installed)"
            continue
        fi

        if SITE_NAME="$site" backup::site "$site" >/dev/null; then
            count=$((count + 1))
        else
            die "backup failed for site: $site"
        fi
    done < <(list_sites)

    log "Backed up $count site(s) into ${PROJECT_BACKUP_DIR:-$PROJECT_BASE_DIR/backups} (stamp $stamp)"
    echo "$count"
}

# ------------------------------------------------------------
# Keep only the newest N stamped backup groups for one site
# (safety valve for disk usage; never deletes latest)
# ------------------------------------------------------------
backup::prune() {
    local site="$1"
    local keep="${2:-${BACKUP_RETENTION:-5}}"

    : "${PROJECT_BASE_DIR:?}"
    local backups_root
    backups_root="$(backup::resolve_dir)"

    [ -d "$backups_root" ] || return 0

    local stamp_dirs=()
    local d
    for d in "$backups_root"/*; do
        [ -d "$d" ] || continue
        if [ -n "$(find "$d" -maxdepth 1 -name "*${site}*" -o -maxdepth 1 -type f 2>/dev/null)" ]; then
            stamp_dirs+=("$d")
        fi
    done

    local total=${#stamp_dirs[@]}
    if [ "$total" -le "$keep" ]; then
        return 0
    fi

    # Sort oldest first; remove oldest beyond the keep budget
    local sorted
    sorted=$(printf '%s\n' "${stamp_dirs[@]}" | sort)
    local excess=$(( total - keep ))

    local old_dir n=0
    while read -r old_dir; do
        [ -z "$old_dir" ] && continue
        n=$(( n + 1 ))
        if [ "$n" -le "$excess" ]; then
            log "Pruning old backup: $old_dir"
            rm -rf "$old_dir"
        fi
    done <<< "$sorted"
}
