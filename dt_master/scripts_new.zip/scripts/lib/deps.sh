#!/usr/bin/env bash
# ============================================================
# lib/deps.sh — dependency resolution engine
#
# Resolves a SYSTEM_DEPENDENCIES JSON contract into installed
# packages, idempotently, in declared order. Never double-installs.
#
# Env contract:
#   SYSTEM_DEPENDENCIES   JSON array:
#     [ { "name": "...", "install_method": "apt|pip|npm|nvm|script",
#         "group": "...", "version": "x.y.z", "repository": "..." } ]
#   PROJECT_BASE_DIR      project root (hosts .nvm)
#   PROJECT_LOGS_DIR      for logging redirection by caller
#   NODE_VERSION          required for npm/nvm methods
#
# Output contract:
#   deps_resolved=true
#   deps_total=N
#   deps_skipped=N
#   deps_<name>=<method:action>      for each resolved dependency
# ============================================================

deps::_node_version_required() {
    require_var NODE_VERSION "NODE_VERSION is required for npm/nvm dependencies"
}

# ------------------------------------------------------------
# Method resolvers. $1=name, $2=pkg JSON line (jq -c row)
# Globals available: NAME VERSION REPO GROUP METHOD
# Every resolver must be idempotent.
# ------------------------------------------------------------

deps::_resolve_apt() {
    local name="$1"
    local repo="${2:-}"

    if ensure_dpkg "$name"; then
        echo "apt:already_installed"
        return 0
    fi

    if [ -n "$repo" ]; then
        log ">> Adding repository: $repo"
        add-apt-repository -y "$repo" || true
        apt-get update -y
    fi

    log ">> Installing via apt: $name"
    apt_install "$name"
}

deps::_resolve_pip() {
    local name="$1"
    log ">> Installing via pip: $name"
    pip install "$name"
}

deps::_resolve_npm() {
    local name="$1"
    deps::_node_version_required

    nvm_load_root
    nvm use "$NODE_VERSION"

    if npm ls -g --depth=0 >/dev/null 2>&1 && npm ls -g "$name" >/dev/null 2>&1; then
        echo "npm:already_installed"
        return 0
    fi

    log ">> Installing via npm: $name"
    npm install -g "$name"
}

deps::_resolve_nvm() {
    local version="$1"
    deps::_node_version_required

    local nvm_root="$PROJECT_BASE_DIR/.nvm"
    local major_check

    if [ -d "$nvm_root/versions/node/v$version" ]; then
        echo "nvm:already_installed"
        return 0
    fi

    log ">> Installing Node via nvm: $version"

    SKIP_NVM=1 run_as_frappe bash -c "
        export NVM_DIR=\"\$PROJECT_BASE_DIR/.nvm\"
        # shellcheck source=/dev/null
        [ -s \"\$NVM_DIR/nvm.sh\" ] && source \"\$NVM_DIR/nvm.sh\"

        if ! command -v nvm >/dev/null 2>&1; then
            echo 'ERROR: nvm not installed'
            exit 1
        fi

        nvm install $version
        nvm use $version
    "
}

deps::_resolve_script() {
    local name="$1"
    local repo="$2"

    if [ -z "$repo" ]; then
        die "dependency '${name}' uses 'script' method but has no repository"
    fi

    log ">> Running script for: $name"

    SKIP_NVM=1 run_as_frappe bash -c "
        curl -fsSL \"$repo\" | bash
    "
}

# ------------------------------------------------------------
# Main entry: resolve the full dependency list.
# Loop runs in the PARENT shell (process substitution) so
# `exit`/`return` behave correctly and state is real state.
# Requires: jq present (bootstrap by caller if not).
# ------------------------------------------------------------
deps::resolve_all() {
    : "${SYSTEM_DEPENDENCIES:?SYSTEM_DEPENDENCIES not set}"
    : "${PROJECT_BASE_DIR:?PROJECT_BASE_DIR not set}"
    : "${PROJECT_LOGS_DIR:?PROJECT_LOGS_DIR not set}"

    # Bootstrap jq if missing (needed before anything else)
    if ! command -v jq >/dev/null 2>&1; then
        log ">> Installing jq (bootstrap)"
        apt-get update -y
        apt_install jq
    fi

    log "== Installing system dependencies (dynamic) =="
    apt-get update -y

    local total=0 skipped=0 failed=0

    while read -r dep; do
        [ -z "$dep" ] && continue

        local name method group version repo action
        name=$(echo "$dep" | jq -r '.name')
        method=$(echo "$dep" | jq -r '.install_method // empty')
        group=$(echo "$dep" | jq -r '.group // empty')
        version=$(echo "$dep" | jq -r '.version // empty')
        repo=$(echo "$dep" | jq -r '.repository // empty')

        [ -z "$name" ] && continue
        total=$((total + 1))

        echo "-------------------------------------------------"
        echo ">> Processing: $name  (method=$method group=$group version=${version:-n/a})"

        case "$method" in

            apt)
                action="$(deps::_resolve_apt "$name" "$repo")" || action="apt:reinstalled"
                ;;

            pip)
                action="$(deps::_resolve_pip "$name")"
                ;;

            npm)
                action="$(deps::_resolve_npm "$name")" || action="npm:installed"
                ;;

            nvm)
                action="$(deps::_resolve_nvm "$version")" || action="nvm:installed"
                ;;

            script)
                action="$(deps::_resolve_script "$name" "$repo")"
                ;;

            *)
                die "Unknown install method: $method (dependency: $name)"
                ;;
        esac

        case "$action" in
            *":already_installed")
                skipped=$((skipped + 1))
                emit "deps_${name}" "${method}:already_installed"
                ;;
            *)
                emit "deps_${name}" "${method}:installed"
                ;;
        esac

    done < <(echo "$SYSTEM_DEPENDENCIES" | jq -c '.[]?')

    echo "-------------------------------------------------"
    log ">> Ensuring core services are running"
    systemctl enable redis-server mariadb || true
    systemctl start redis-server mariadb || true

    echo "== Dependency resolution complete =="
    emit "deps_resolved" "true"
    emit "deps_total" "$total"
    emit "deps_skipped" "$skipped"
}
