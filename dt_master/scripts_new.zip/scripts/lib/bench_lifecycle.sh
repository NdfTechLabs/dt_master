#!/usr/bin/env bash
# ============================================================
# lib/bench_lifecycle.sh — bench-wide lifecycle domain
#
# Entry points (used by bin/node/* wrappers):
#   bench::update       — backup → bench update → rebuild → reload
#   bench::migrate      — migrate one site (SITE_NAME) or every site
#   bench::restore      — restore a stamped backup into a site
#   bench::remove       — teardown: stop services, drop sites
#                         (databases are KEPT by default), remove files
# ============================================================

# ============================================================
# bench::update — safe rolling update of the whole bench
#
# Env: PROJECT_BASE_DIR
# Opt: BENCH_UPDATE_SKIP_BACKUP=true  — skip the pre-update backup
#      BENCH_UPDATE_PRUNE_KEEP=N      — backup retention (default 5)
#
# Steps:
#   1. Full backup of every site (blocker on failure)
#   2. bench update (requirements + build + patch handled by bench)
#   3. migrate each site (idempotent)
#   4. supervisor reread/update + restart groups (requires root)
#
# Output:
#   bench_updated=true                  backup_dir=...
#   bench_update_sites=N                bench_update_rollback_hint=...
# ============================================================
bench::update() {
    : "${PROJECT_BASE_DIR:?}"
    require_venv

    local bench_dir="${PROJECT_BASE_DIR}/bench"
    [ -d "$bench_dir" ] || die "Bench directory not found at $bench_dir"

    log "== Updating Bench =="

    # ------------------------------------------------------------
    # 1. Pre-update backup (default ON, contract-safe skip flag)
    # ------------------------------------------------------------
    local backup_dir="skipped"
    local sites_backed_up=0

    if [ "${BENCH_UPDATE_SKIP_BACKUP:-false}" != "true" ]; then
        log ">> Creating pre-update backup"
        sites_backed_up="$(backup::all_sites)" || die "Abort: pre-update backup failed — not updating"

        local first_site_backup_dir
        backup_dir="${PROJECT_BACKUP_DIR:-$PROJECT_BASE_DIR/backups}"

        backup_dir="$backup_dir"
        emit "backup_dir" "$backup_dir"

        # retention sweep (best-effort)
        local site
        while read -r site; do
            [ -z "$site" ] && continue
            backup::prune "$site" "${BENCH_UPDATE_PRUNE_KEEP:-5}" || true
        done < <(list_sites)
    else
        log ">> Skipping pre-update backup (BENCH_UPDATE_SKIP_BACKUP=true)"
        emit "backup_dir" "skipped"
    fi

    emit "bench_update_sites" "$sites_backed_up"

    # ------------------------------------------------------------
    # 2. bench update (as frappe)
    # ------------------------------------------------------------
    log ">> Running bench update"
    if ! run_as_frappe bash -c "
        set -e
        source '${PROJECT_BASE_DIR}/.venv/bin/activate'
        cd '${bench_dir}'
        export NODE_OPTIONS='--max-old-space-size=4096'
        export FRAPPE_NODE_OPTIONS='--max-old-space-size=4096'
        bench update --no-backup
    "; then
        die "bench update failed — restore from: $backup_dir"
    fi

    # ------------------------------------------------------------
    # 3. Migrate every site (idempotent safety net)
    # ------------------------------------------------------------
    log ">> Migrating sites"
    local site count=0
    while read -r site; do
        [ -z "$site" ] && continue
        log ">> Migrating site: $site"
        bench_exec --site "$site" migrate || die "migrate failed for site $site — restore from: $backup_dir"
        count=$((count + 1))
    done < <(list_sites)

    # ------------------------------------------------------------
    # 4. Reload supervisor services
    # ------------------------------------------------------------
    log ">> Reloading Supervisor configuration"
    if [ -S /var/run/supervisor.sock ] && supervisorctl pid >/dev/null 2>&1; then
        supervisorctl reread || true
        supervisorctl update || true
        supervisorctl restart bench-web:* bench-workers:* || true
    else
        warn "Supervisor not available for reload"
    fi

    log "== Bench update complete =="
    emit "bench_updated" "true"
    emit "bench_update_rollback_hint" "$backup_dir"
}

# ============================================================
# bench::migrate — migrate SITE_NAME (if set) or all sites
# Env: PROJECT_BASE_DIR (+ optional SITE_NAME)
# ============================================================
bench::migrate() {
    : "${PROJECT_BASE_DIR:?}"

    if [ -n "${SITE_NAME:-}" ]; then
        log "== Migrating site: $SITE_NAME =="
        if ! site_exists "$SITE_NAME"; then
            die "Site does not exist: $SITE_NAME"
        fi
        bench_exec --site "$SITE_NAME" migrate
        clear_cache_and_reload
        log "== Migration complete: $SITE_NAME =="
        return 0
    fi

    log "== Migrating every site =="
    local site
    while read -r site; do
        [ -z "$site" ] && continue
        log ">> Migrating site: $site"
        bench_exec --site "$site" migrate
    done < <(list_sites)

    log "== Migration complete =="
}

# ============================================================
# bench::restore — restore a stamp backup into a site
#
# Env: PROJECT_BASE_DIR SITE_NAME RESTORE_DIR (stamped backup dir)
#      Optional: RESTORE_FILES_ONLY=true
#
# Uses bench restore for DB (+ --with-files when available).
# Output: site_restored=true / restore_dir=...
# ============================================================
bench::restore() {
    require_env PROJECT_BASE_DIR SITE_NAME RESTORE_DIR

    local bench_dir="${PROJECT_BASE_DIR}/bench"
    [ -d "$bench_dir" ] || die "Bench directory not found at $bench_dir"
    [ -d "$RESTORE_DIR" ] || die "Restore dir not found: $RESTORE_DIR"

    if ! site_exists "$SITE_NAME"; then
        die "Site does not exist: $SITE_NAME"
    fi

    log "Restoring site $SITE_NAME from $RESTORE_DIR"

    local db_file tar_file

    if [ "${RESTORE_FILES_ONLY:-false}" = "true" ]; then
        tar_file="$(find "$RESTORE_DIR" -name "*-private-files.tar" -print0 2>/dev/null | head -z -n1 || true)"
        [ -n "$tar_file" ] || die "No files tar found in $RESTORE_DIR"
        bench_exec --site "$SITE_NAME" partial-restore \
            --with-files "$tar_file"
    else
        db_file="$(find "$RESTORE_DIR" -name "*-database.sql.gz" -print0 2>/dev/null | head -z -n1 || true)"
        [ -n "$db_file" ] || die "No database sql.gz found in $RESTORE_DIR"

        tar_file="$(find "$RESTORE_DIR" -name "*-private-files.tar" -print0 2>/dev/null | head -z -n1 || true)"

        if [ -n "$tar_file" ]; then
            bench_exec --site "$SITE_NAME" restore \
                --with-files "$db_file" "$tar_file"
        else
            bench_exec --site "$SITE_NAME" restore "$db_file"
        fi
    fi

    clear_cache_and_reload

    log "Site restored successfully"
    emit "site_restored" "true"
    emit "restore_dir" "$RESTORE_DIR"
}

# ============================================================
# bench::remove — full bench teardown
#
# Env: PROJECT_BASE_DIR (BENCH_DIR derived)
# Pol:
#   - sites dropped via bench (site dirs removed)
#   - DATABASES ARE KEPT (default; DB removal is a separate op)
#   - supervisor link + tenant nginx confs removed
#   - bench + venv deleted (.nvm and logs preserved)
# Opt: REMOVE_STOP_ONLY=true  → stop services, remove nothing
#
# Output:
#   bench_removed=true   databases_kept=true   sites_dropped=N
# ============================================================
bench::remove() {
    : "${PROJECT_BASE_DIR:?}"
    require_root

    local bench_dir="${PROJECT_BASE_DIR}/bench"
    [ -d "$bench_dir" ] || die "Bench directory not found at $bench_dir"

    log "== Removing bench: $bench_dir =="

    local supervisor_link="/etc/supervisor/conf.d/bench.conf"

    # ------------------------------------------------------------
    # 1. Stop supervisor-managed services (node + site groups)
    # ------------------------------------------------------------
    log ">> Stopping supervisor-managed services"
    if [ -S /var/run/supervisor.sock ] && supervisorctl pid >/dev/null 2>&1; then
        supervisorctl stop bench-web:* bench-workers:* bench-redis:* || true
    else
        warn "Supervisor not running — skipping service stop"
    fi

    if [ "${REMOVE_STOP_ONLY:-false}" = "true" ]; then
        log "REMOVE_STOP_ONLY requested — stopping only, removing nothing"
        emit "bench_removed" "false"
        emit "stop_only" "true"
        return 0
    fi

    # ------------------------------------------------------------
    # 2. Drop sites via bench (keeps databases)
    # ------------------------------------------------------------
    local dropped=0 site
    while read -r site; do
        [ -z "$site" ] && continue

        log ">> Dropping site (DB kept): $site"

        if bench_exec drop-site "$site" --force; then
            dropped=$((dropped + 1))
        else
            # bench drop-site has prerequisites (frappe ownership).
            # Fall back to safe manual handling: remove site dir only,
            # never touch the database (contract: keep DBs).
            warn "bench drop-site failed for $site — removing site directory only (DB kept)"
            rm -rf "$bench_dir/sites/$site"
            dropped=$((dropped + 1))
        fi
    done < <(list_sites)

    # Defensive: clear any residual site directories (DB-safe)
    # after bench drop-site may have archived them.
    # ------------------------------------------------------------
    # 3. Remove supervisor bench link
    # ------------------------------------------------------------
    log ">> Removing Supervisor bench link"
    if [ -L "$supervisor_link" ] || [ -e "$supervisor_link" ]; then
        rm -f "$supervisor_link"
    fi

    supervisorctl reread || true
    supervisorctl update || true

    # ------------------------------------------------------------
    # 4. Remove tenant nginx configs + reload
    # ------------------------------------------------------------
    log ">> Removing tenant nginx configs"
    local removed_nginx=0 tenant_conf
    for tenant_conf in /etc/nginx/conf.d/tenant_*.conf; do
        [ -e "$tenant_conf" ] || continue
        rm -f "$tenant_conf"
        removed_nginx=$((removed_nginx + 1))
    done

    if [ "$removed_nginx" -gt 0 ]; then
        nginx -t || true
        systemctl reload nginx || true
    fi

    # ------------------------------------------------------------
    # 5. Delete bench + venv files (DB-safe)
    # ------------------------------------------------------------
    log ">> Removing bench filesystem"
    rm -rf "$bench_dir"
    rm -rf "${PROJECT_BASE_DIR}/.venv"

    log "== Bench removed (databases kept) =="

    emit "bench_removed" "true"
    emit "databases_kept" "true"
    emit "sites_dropped" "$dropped"
    emit "nginx_confs_removed" "$removed_nginx"
}
